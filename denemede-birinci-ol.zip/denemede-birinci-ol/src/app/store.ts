import { useEffect, useState } from "react";
import { DEFAULT_EXAM_DATE } from "./data";

export type Video = { id: string; topicId: string; url: string; title: string; watched: boolean; resume: string };
export type Book = { id: string; name: string };
export type Solve = { id: string; topicId: string; bookId: string | null; count: number; correct: number; date: string };
export type State = {
  profile: { name: string; className: string; goal: string } | null;
  setupDone: boolean;
  examDate: string;
  videos: Video[];
  books: Book[];
  solves: Solve[];
  doneTopics: string[];
};

const KEY = "denemede-birinci-v1";
const initial: State = { profile: null, setupDone: false, examDate: DEFAULT_EXAM_DATE, videos: [], books: [], solves: [], doneTopics: [] };

export const uid = () => Math.random().toString(36).slice(2, 10);

export function useAppState() {
  const [state, setState] = useState<State>(initial);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setState({ ...initial, ...JSON.parse(raw) });
    } catch {}
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) localStorage.setItem(KEY, JSON.stringify(state));
  }, [state, ready]);
  const update = (fn: (s: State) => State) => setState((s) => fn(s));
  return { state, update, ready };
}
