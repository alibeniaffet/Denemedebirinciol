import { useEffect, useMemo, useRef, useState } from "react";
import { SUBJECTS, ALL_TOPICS, findTopic, youtubeId, parseTime, fmtTime, daysLeft, buildPlan, type Subject } from "./data";
import { useAppState, uid, type State, type Video } from "./store";

type Tab = "home" | "videos" | "solve" | "settings";
type Update = (fn: (s: State) => State) => void;

export default function App() {
  const { state, update, ready } = useAppState();
  const [tab, setTab] = useState<Tab>("home");
  const [playing, setPlaying] = useState<Video | null>(null);

  if (!ready) return <div className="app-shell" />;
  if (!state.profile) return <ProfileSetup update={update} />;

  return (
    <div className="app-shell">
      {!state.setupDone ? (
        <div className="px-4 pb-28 pt-6">
          <h1 className="font-display text-3xl">Videolarını seç 🎬</h1>
          <p className="mt-1 text-sm text-muted-foreground">Her konuya YouTube'dan bir veya daha fazla video ekle. Sonra da ekleyebilirsin.</p>
          <VideoLibrary state={state} update={update} onPlay={setPlaying} />
          <div className="fixed inset-x-0 bottom-0 mx-auto max-w-md p-4">
            <button className="btn-primary w-full" onClick={() => update((s) => ({ ...s, setupDone: true }))}>
              Tamam, başlayalım →
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="px-4 pb-28 pt-6">
            {tab === "home" && <Home state={state} update={update} go={setTab} />}
            {tab === "videos" && (
              <>
                <h1 className="font-display text-3xl">Videolar</h1>
                <VideoLibrary state={state} update={update} onPlay={setPlaying} />
              </>
            )}
            {tab === "solve" && <Solve state={state} update={update} />}
            {tab === "settings" && <Settings state={state} update={update} />}
          </div>
          <nav className="tabbar">
            {([["home", "🏆", "Program"], ["videos", "▶", "Videolar"], ["solve", "✎", "Soru"], ["settings", "⚙", "Ayarlar"]] as const).map(([k, i, l]) => (
              <button key={k} onClick={() => setTab(k)} className={tab === k ? "tab tab-active" : "tab"}>
                <span className="text-lg leading-none">{i}</span>
                <span className="text-[11px]">{l}</span>
              </button>
            ))}
          </nav>
        </>
      )}
      {playing && <Player video={playing} update={update} onClose={() => setPlaying(null)} />}
    </div>
  );
}

function ProfileSetup({ update }: { update: Update }) {
  const [name, setName] = useState("");
  const [className, setClassName] = useState("10");
  const [goal, setGoal] = useState("Okul birincisi");
  return (
    <div className="app-shell flex flex-col justify-center px-6">
      <div className="medal">1</div>
      <h1 className="mt-6 font-display text-4xl leading-tight">Denemede<br /><span className="text-primary">birinci ol!</span></h1>
      <p className="mt-2 text-muted-foreground">Önce profilini oluştur.</p>
      <div className="mt-8 space-y-3">
        <input className="field" placeholder="Adın" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="field" placeholder="Sınıf / şube (ör. 10-A)" value={className} onChange={(e) => setClassName(e.target.value)} />
        <input className="field" placeholder="Hedefin" value={goal} onChange={(e) => setGoal(e.target.value)} />
        <button className="btn-primary w-full" disabled={!name.trim()} onClick={() => update((s) => ({ ...s, profile: { name: name.trim(), className, goal } }))}>
          Profili oluştur
        </button>
      </div>
    </div>
  );
}

function Home({ state, update, go }: { state: State; update: Update; go: (t: Tab) => void }) {
  const left = daysLeft(state.examDate);
  const remaining = ALL_TOPICS.filter((t) => !state.doneTopics.includes(t.id)).map((t) => t.id);
  const plan = useMemo(() => buildPlan(remaining, Math.max(1, left)), [remaining.join(), left]);
  const today = plan[0] ?? [];
  const totalQ = ALL_TOPICS.reduce((a, t) => a + t.q, 0);
  const doneQ = ALL_TOPICS.filter((t) => state.doneTopics.includes(t.id)).reduce((a, t) => a + t.q, 0);
  const solved = state.solves.reduce((a, s) => a + s.count, 0);
  const watched = state.videos.filter((v) => v.watched).length;
  const toggle = (id: string) =>
    update((s) => ({ ...s, doneTopics: s.doneTopics.includes(id) ? s.doneTopics.filter((x) => x !== id) : [...s.doneTopics, id] }));

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-muted-foreground">Merhaba {state.profile?.name} 👋</p>
        <h1 className="font-display text-3xl">Denemede birinci ol!</h1>
      </div>
      <div className="hero-card">
        <div className="text-sm opacity-80">1. Deneme'ye kalan</div>
        <div className="font-display text-6xl">{left} <span className="text-2xl">gün</span></div>
        <div className="mt-1 text-xs opacity-70">Tahmini tarih: {new Date(state.examDate).toLocaleDateString("tr-TR", { day: "numeric", month: "long" })} (ekimin son haftası)</div>
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-primary-foreground/20">
          <div className="h-full rounded-full bg-primary-foreground" style={{ width: `${(doneQ / totalQ) * 100}%` }} />
        </div>
        <div className="mt-1 text-xs opacity-80">Denemedeki {totalQ} sorunun %{Math.round((doneQ / totalQ) * 100)}'lik kısmının konusu bitti</div>
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        <Stat n={state.doneTopics.length} l="konu bitti" />
        <Stat n={watched} l="video izlendi" />
        <Stat n={solved} l="soru çözüldü" />
      </div>

      <section>
        <h2 className="section-title">Bugünün programı</h2>
        {today.length === 0 ? (
          <p className="card text-sm">Tüm konular bitti! Şimdi bol soru çöz 💪</p>
        ) : (
          <div className="space-y-2">
            {today.map((id) => <TopicRow key={id} id={id} done={false} onToggle={toggle} />)}
            <p className="text-xs text-muted-foreground">Her konu için: videoyu izle → 20-40 soru çöz → yanlışlarını tekrar et.</p>
          </div>
        )}
      </section>

      {plan.length > 1 && (
        <section>
          <h2 className="section-title">Sonraki günler</h2>
          <div className="space-y-2">
            {plan.slice(1, 7).map((d, i) => (
              <div key={i} className="card">
                <div className="text-xs font-semibold text-muted-foreground">{dayLabel(i + 1)}</div>
                <div className="mt-1 text-sm">{d.length ? d.map((id) => findTopic(id)?.name).join(" • ") : "Tekrar + soru çözümü"}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="section-title">Tüm konular</h2>
        {groupSubjects().map(([g, subs]) => (
          <div key={g} className="mb-4">
            <div className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">{g}</div>
            {subs.map((s) => (
              <div key={s.id} className="mb-2 space-y-1">
                <div className="flex items-center gap-2 text-sm font-semibold"><span className="dot" style={{ background: s.color }} />{s.name}</div>
                {s.topics.map((t) => <TopicRow key={t.id} id={t.id} done={state.doneTopics.includes(t.id)} onToggle={toggle} />)}
              </div>
            ))}
          </div>
        ))}
      </section>
      <button className="btn-ghost w-full" onClick={() => go("solve")}>Soru çözümü ekle →</button>
    </div>
  );
}

function dayLabel(i: number) {
  const d = new Date(); d.setDate(d.getDate() + i);
  return i === 1 ? "Yarın" : d.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "short" });
}

function TopicRow({ id, done, onToggle }: { id: string; done: boolean; onToggle: (id: string) => void }) {
  const t = findTopic(id)!;
  return (
    <button onClick={() => onToggle(id)} className={done ? "topic-row opacity-60" : "topic-row"}>
      <span className={done ? "check check-on" : "check"}>{done ? "✓" : ""}</span>
      <span className="flex-1 text-left text-sm"><span className={done ? "line-through" : ""}>{t.name}</span><span className="block text-xs text-muted-foreground">{t.subject.name}</span></span>
      <span className="badge">{t.q} soru</span>
    </button>
  );
}

function Stat({ n, l }: { n: number; l: string }) {
  return <div className="card py-3"><div className="font-display text-2xl">{n}</div><div className="text-[11px] text-muted-foreground">{l}</div></div>;
}

function groupSubjects(): [string, Subject[]][] {
  const m = new Map<string, Subject[]>();
  SUBJECTS.forEach((s) => m.set(s.group, [...(m.get(s.group) ?? []), s]));
  return [...m.entries()];
}

function VideoLibrary({ state, update, onPlay }: { state: State; update: Update; onPlay: (v: Video) => void }) {
  const [open, setOpen] = useState<string | null>(SUBJECTS[0].id);
  return (
    <div className="mt-4 space-y-3">
      {groupSubjects().map(([g, subs]) => (
        <div key={g}>
          <div className="mb-1 text-xs font-bold uppercase tracking-wider text-muted-foreground">{g}</div>
          {subs.map((s) => {
            const count = state.videos.filter((v) => s.topics.some((t) => t.id === v.topicId)).length;
            return (
              <div key={s.id} className="card mb-2 p-0">
                <button className="flex w-full items-center gap-2 p-3 text-left font-semibold" onClick={() => setOpen(open === s.id ? null : s.id)}>
                  <span className="dot" style={{ background: s.color }} />{s.name}
                  <span className="ml-auto badge">{count} video</span>
                  <span>{open === s.id ? "▴" : "▾"}</span>
                </button>
                {open === s.id && (
                  <div className="space-y-4 border-t border-border p-3">
                    {s.topics.map((t) => <TopicVideos key={t.id} topicId={t.id} state={state} update={update} onPlay={onPlay} />)}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function TopicVideos({ topicId, state, update, onPlay }: { topicId: string; state: State; update: Update; onPlay: (v: Video) => void }) {
  const t = findTopic(topicId)!;
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [err, setErr] = useState("");
  const vids = state.videos.filter((v) => v.topicId === topicId);
  const add = () => {
    if (!youtubeId(url)) return setErr("Geçerli bir YouTube linki yapıştır");
    update((s) => ({ ...s, videos: [...s.videos, { id: uid(), topicId, url: url.trim(), title: title.trim() || `${t.name} – Video ${vids.length + 1}`, watched: false, resume: "" }] }));
    setUrl(""); setTitle(""); setErr("");
  };
  const patch = (id: string, p: Partial<Video>) => update((s) => ({ ...s, videos: s.videos.map((v) => (v.id === id ? { ...v, ...p } : v)) }));
  return (
    <div>
      <div className="text-sm font-semibold">{t.name} <span className="text-xs font-normal text-muted-foreground">· {t.q} soru</span></div>
      <div className="mt-2 space-y-2">
        {vids.map((v) => {
          const yid = youtubeId(v.url);
          return (
            <div key={v.id} className="video-item">
              <button className="relative shrink-0" onClick={() => onPlay(v)}>
                <img src={`https://i.ytimg.com/vi/${yid}/mqdefault.jpg`} alt="" className="h-14 w-24 rounded-md object-cover" />
                <span className="play-badge">▶</span>
              </button>
              <div className="min-w-0 flex-1">
                <button className="block w-full truncate text-left text-sm font-medium" onClick={() => onPlay(v)}>{v.title}</button>
                {v.resume && !v.watched && <div className="text-xs text-warning">Kaldığın yer: {v.resume}</div>}
                <div className="mt-1 flex flex-wrap gap-1">
                  <button className={v.watched ? "chip chip-success" : "chip"} onClick={() => patch(v.id, { watched: !v.watched, resume: "" })}>{v.watched ? "✓ İzlendi" : "İzlendi"}</button>
                  <button className="chip" onClick={() => { const r = prompt("Kaldığın yer (ör. 12:34)", v.resume); if (r !== null) patch(v.id, { resume: r.trim(), watched: false }); }}>Yarıda kaldı</button>
                  <button className="chip chip-danger" onClick={() => update((s) => ({ ...s, videos: s.videos.filter((x) => x.id !== v.id) }))}>Sil</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex flex-col gap-2">
        <input className="field" placeholder="YouTube linki yapıştır" value={url} onChange={(e) => setUrl(e.target.value)} />
        {url && <input className="field" placeholder="Video adı (isteğe bağlı)" value={title} onChange={(e) => setTitle(e.target.value)} />}
        {err && <div className="text-xs text-destructive">{err}</div>}
        {url && <button className="btn-primary" onClick={add}>+ Video ekle</button>}
      </div>
    </div>
  );
}

function Player({ video, update, onClose }: { video: Video; update: Update; onClose: () => void }) {
  const yid = youtubeId(video.url);
  const start = parseTime(video.resume);
  const [resume, setResume] = useState(video.resume);
  const [cur, setCur] = useState(start);
  const frame = useRef<HTMLIFrameElement>(null);
  const patch = (p: Partial<Video>) => update((s) => ({ ...s, videos: s.videos.map((v) => (v.id === video.id ? { ...v, ...p } : v)) }));

  // YouTube oynatıcısından anlık süreyi dinle (kaldığın yeri otomatik yakalamak için)
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (typeof e.data !== "string") return;
      try {
        const t = JSON.parse(e.data)?.info?.currentTime;
        if (typeof t === "number" && t > 0) setCur(Math.floor(t));
      } catch {}
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);
  const listen = () => frame.current?.contentWindow?.postMessage(JSON.stringify({ event: "listening", id: 1, channel: "widget" }), "*");

  const closeAndSave = () => {
    if (!video.watched && cur > 5) patch({ resume: fmtTime(cur) });
    onClose();
  };
  return (
    <div className="player-overlay">
      <div className="mx-auto w-full max-w-md">
        <div className="flex items-center justify-between p-3">
          <div className="truncate font-semibold">{video.title}</div>
          <button className="chip" onClick={closeAndSave}>Kapat ✕</button>
        </div>
        <div className="aspect-video w-full bg-foreground">
          <iframe
            ref={frame}
            onLoad={listen}
            className="h-full w-full"
            src={`https://www.youtube.com/embed/${yid}?autoplay=1&playsinline=1&enablejsapi=1&rel=0&start=${start}`}
            referrerPolicy="strict-origin-when-cross-origin"
            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
            allowFullScreen
            title={video.title}
          />
        </div>
        <div className="space-y-3 p-4">
          {start > 0 && <p className="text-sm text-muted-foreground">Kaldığın yerden ({video.resume}) başlatıldı.</p>}
          <p className="text-xs text-muted-foreground">Kapatırken kaldığın yer otomatik kaydedilir. Şu an: {fmtTime(cur)}</p>
          <button className="btn-primary w-full" onClick={() => { patch({ watched: true, resume: "" }); onClose(); }}>✓ İzlendi</button>
          <div className="flex gap-2">
            <input className="field flex-1" placeholder="Kaldığım yer (ör. 12:34)" value={resume} onChange={(e) => setResume(e.target.value)} />
            <button className="btn-ghost" onClick={() => setResume(fmtTime(cur))}>Şimdiki</button>
          </div>
          <button className="btn-ghost w-full" onClick={() => { patch({ resume: resume.trim(), watched: false }); onClose(); }}>Yarıda kaldı, kaydet</button>
          <a className="block text-center text-xs text-muted-foreground underline" href={video.url} target="_blank" rel="noreferrer">YouTube uygulamasında aç</a>
        </div>
      </div>
    </div>
  );
}

function Solve({ state, update }: { state: State; update: Update }) {
  const [topicId, setTopicId] = useState(ALL_TOPICS[0].id);
  const [bookId, setBookId] = useState<string>("");
  const [count, setCount] = useState("");
  const [correct, setCorrect] = useState("");
  const add = () => {
    const c = parseInt(count, 10);
    if (!c || c <= 0) return;
    const ok = Math.min(c, Math.max(0, parseInt(correct, 10) || 0));
    update((s) => ({ ...s, solves: [{ id: uid(), topicId, bookId: bookId || null, count: c, correct: ok, date: new Date().toISOString() }, ...s.solves] }));
    setCount(""); setCorrect("");
  };
  const bySubject = SUBJECTS.map((s) => {
    const list = state.solves.filter((x) => s.topics.some((t) => t.id === x.topicId));
    return { s, n: list.reduce((a, x) => a + x.count, 0), ok: list.reduce((a, x) => a + x.correct, 0) };
  });
  const max = Math.max(1, ...bySubject.map((b) => b.n));
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl">Soru çözümü</h1>
      <div className="card space-y-2">
        <label className="text-xs font-semibold text-muted-foreground">Konu</label>
        <select className="field" value={topicId} onChange={(e) => setTopicId(e.target.value)}>
          {SUBJECTS.map((s) => (
            <optgroup key={s.id} label={s.name}>{s.topics.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</optgroup>
          ))}
        </select>
        {state.books.length > 0 && (
          <>
            <label className="text-xs font-semibold text-muted-foreground">Kaynak kitap</label>
            <select className="field" value={bookId} onChange={(e) => setBookId(e.target.value)}>
              <option value="">Kaynak seçme (atla)</option>
              {state.books.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </>
        )}
        <div className="flex gap-2">
          <input className="field flex-1" inputMode="numeric" placeholder="Kaç soru?" value={count} onChange={(e) => setCount(e.target.value.replace(/\D/g, ""))} />
          <input className="field flex-1" inputMode="numeric" placeholder="Kaç doğru?" value={correct} onChange={(e) => setCorrect(e.target.value.replace(/\D/g, ""))} />
        </div>
        <button className="btn-primary w-full" onClick={add}>Kaydet</button>
      </div>
      <section>
        <h2 className="section-title">Derslere göre</h2>
        <div className="card space-y-2">
          {bySubject.map(({ s, n, ok }) => (
            <div key={s.id}>
              <div className="flex justify-between text-sm"><span>{s.name}</span><span className="text-muted-foreground">{n} soru{n ? ` · %${Math.round((ok / n) * 100)} doğru` : ""}</span></div>
              <div className="h-2 rounded-full bg-muted"><div className="h-full rounded-full" style={{ width: `${(n / max) * 100}%`, background: s.color }} /></div>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="section-title">Konulara göre</h2>
        {SUBJECTS.map((s) => (
          <div key={s.id} className="card mb-2 space-y-1">
            <div className="flex items-center gap-2 text-sm font-semibold"><span className="dot" style={{ background: s.color }} />{s.name}</div>
            {s.topics.map((t) => {
              const list = state.solves.filter((x) => x.topicId === t.id);
              const n = list.reduce((a, x) => a + x.count, 0);
              const ok = list.reduce((a, x) => a + x.correct, 0);
              return (
                <div key={t.id} className="flex items-center justify-between gap-2 text-xs">
                  <span className="min-w-0 flex-1 truncate">{t.name}</span>
                  <span className="shrink-0 text-muted-foreground">{n} soru{n ? ` · %${Math.round((ok / n) * 100)}` : ""}</span>
                </div>
              );
            })}
          </div>
        ))}
      </section>
      <section>
        <h2 className="section-title">Geçmiş</h2>
        {state.solves.length === 0 && <p className="text-sm text-muted-foreground">Henüz kayıt yok.</p>}
        <div className="space-y-2">
          {state.solves.slice(0, 50).map((x) => {
            const t = findTopic(x.topicId);
            const b = state.books.find((b) => b.id === x.bookId);
            return (
              <div key={x.id} className="card flex items-center gap-2 py-2">
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{t?.name}</div>
                  <div className="text-xs text-muted-foreground">{t?.subject.name}{b ? ` · ${b.name}` : ""} · {new Date(x.date).toLocaleDateString("tr-TR")}</div>
                </div>
                <span className="badge">{x.correct}/{x.count}</span>
                <button className="chip chip-danger" onClick={() => update((s) => ({ ...s, solves: s.solves.filter((y) => y.id !== x.id) }))}>✕</button>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

function Settings({ state, update }: { state: State; update: Update }) {
  const [book, setBook] = useState("");
  const p = state.profile!;
  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl">Ayarlar</h1>
      <div className="card space-y-2">
        <h2 className="font-semibold">Profil</h2>
        <input className="field" value={p.name} onChange={(e) => update((s) => ({ ...s, profile: { ...p, name: e.target.value } }))} />
        <input className="field" value={p.className} onChange={(e) => update((s) => ({ ...s, profile: { ...p, className: e.target.value } }))} />
        <input className="field" value={p.goal} onChange={(e) => update((s) => ({ ...s, profile: { ...p, goal: e.target.value } }))} />
      </div>
      <div className="card space-y-2">
        <h2 className="font-semibold">Deneme tarihi</h2>
        <p className="text-xs text-muted-foreground">Kesin tarih açıklanınca buradan güncelle. Program otomatik yeniden dağıtılır.</p>
        <input type="date" className="field" value={state.examDate} onChange={(e) => e.target.value && update((s) => ({ ...s, examDate: e.target.value }))} />
      </div>
      <div className="card space-y-2">
        <h2 className="font-semibold">Kaynak kitaplar</h2>
        <p className="text-xs text-muted-foreground">Kitabın yoksa boş bırakabilirsin.</p>
        {state.books.map((b) => (
          <div key={b.id} className="flex items-center justify-between text-sm">
            <span>📘 {b.name}</span>
            <button className="chip chip-danger" onClick={() => update((s) => ({ ...s, books: s.books.filter((x) => x.id !== b.id) }))}>Sil</button>
          </div>
        ))}
        <div className="flex gap-2">
          <input className="field flex-1" placeholder="Kitap adı" value={book} onChange={(e) => setBook(e.target.value)} />
          <button className="btn-primary" onClick={() => { if (book.trim()) { update((s) => ({ ...s, books: [...s.books, { id: uid(), name: book.trim() }] })); setBook(""); } }}>Ekle</button>
        </div>
      </div>
      <button className="btn-ghost w-full" onClick={() => { if (confirm("Tüm veriler silinsin mi?")) update(() => ({ profile: null, setupDone: false, examDate: state.examDate, videos: [], books: [], solves: [], doneTopics: [] })); }}>
        Her şeyi sıfırla
      </button>
    </div>
  );
}
