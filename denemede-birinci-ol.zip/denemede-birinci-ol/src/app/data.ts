export type Topic = { id: string; name: string; q: number };
export type Subject = { id: string; name: string; group: string; color: string; topics: Topic[] };

// 10. Sınıf GİS 1 Deneme konuları (q = denemedeki soru sayısı)
export const SUBJECTS: Subject[] = [
  {
    id: "tr", name: "Türkçe", group: "Türkçe", color: "var(--sub-tr)",
    topics: [
      { id: "tr1", name: "Yazım Kuralları", q: 1 },
      { id: "tr2", name: "Noktalama İşaretleri", q: 1 },
      { id: "tr3", name: "İslamiyet'in Kabulünden Önceki Türk Şiiri", q: 9 },
      { id: "tr4", name: "Âşık Edebiyatı", q: 11 },
      { id: "tr5", name: "Sözlü Kültür ve Edebiyat", q: 3 },
      { id: "tr6", name: "Sıfat", q: 2 },
      { id: "tr7", name: "İsim", q: 1 },
      { id: "tr8", name: "Anlatım Teknikleri", q: 1 },
      { id: "tr9", name: "Paragrafta Konu ve Ana Düşünce", q: 1 },
    ],
  },
  {
    id: "mat", name: "Matematik", group: "Matematik", color: "var(--sub-mat)",
    topics: [
      { id: "mat1", name: "Dik Üçgende Trigonometrik Oranlar ve Özdeşlikler", q: 29 },
      { id: "mat2", name: "Özel Dörtgenler", q: 1 },
    ],
  },
  {
    id: "tar", name: "Tarih", group: "Sosyal", color: "var(--sub-tar)",
    topics: [
      { id: "tar1", name: "1040-1299 Arası Askerî Mücadeleler ve Etkileri", q: 11 },
      { id: "tar2", name: "Türklerde Devlet ve Ordu Teşkilatı (Değişim ve Süreklilik)", q: 1 },
    ],
  },
  {
    id: "cog", name: "Coğrafya", group: "Sosyal", color: "var(--sub-cog)",
    topics: [{ id: "cog1", name: "Coğrafi Bakış", q: 10 }],
  },
  {
    id: "fel", name: "Felsefe", group: "Sosyal", color: "var(--sub-fel)",
    topics: [
      { id: "fel1", name: "Felsefenin Anlamı", q: 2 },
      { id: "fel2", name: "Felsefenin Anlamına Yönelik Farklı Görüşler", q: 1 },
      { id: "fel3", name: "Felsefi Düşüncenin Özellikleri", q: 1 },
    ],
  },
  {
    id: "din", name: "Din Kültürü", group: "Sosyal", color: "var(--sub-din)",
    topics: [
      { id: "din1", name: "Allah İnancının İnsan Hayatındaki Yeri", q: 3 },
      { id: "din2", name: "Allah'ın Varlığı ve Birliği (Akli ve Naklî Deliller)", q: 1 },
    ],
  },
  {
    id: "fiz", name: "Fizik", group: "Fen Bilimleri", color: "var(--sub-fiz)",
    topics: [
      { id: "fiz1", name: "Sabit Hızlı Hareket", q: 6 },
      { id: "fiz2", name: "Bir Boyutta Sabit İvmeli Hareket", q: 4 },
    ],
  },
  {
    id: "kim", name: "Kimya", group: "Fen Bilimleri", color: "var(--sub-kim)",
    topics: [
      { id: "kim1", name: "Kimyasal Tepkimeler", q: 1 },
      { id: "kim2", name: "Kimyasal Tepkimelerin Oluşumu", q: 4 },
      { id: "kim3", name: "Kimyasal Tepkime Türleri", q: 2 },
      { id: "kim4", name: "Çökelme Tepkimeleri", q: 1 },
      { id: "kim5", name: "Asit-Baz Tepkimeleri", q: 1 },
      { id: "kim6", name: "İndirgenme-Yükseltgenme Tepkimeleri", q: 1 },
    ],
  },
  {
    id: "biy", name: "Biyoloji", group: "Fen Bilimleri", color: "var(--sub-biy)",
    topics: [
      { id: "biy1", name: "ATP'nin Yapısı ve Enerji Aktarımındaki Rolü", q: 5 },
      { id: "biy2", name: "Fotosentezin Canlılar Açısından Önemi", q: 2 },
      { id: "biy3", name: "Fotosentez Süreci", q: 3 },
    ],
  },
];

export const ALL_TOPICS = SUBJECTS.flatMap((s) => s.topics.map((t) => ({ ...t, subject: s })));
export const findTopic = (id: string) => ALL_TOPICS.find((t) => t.id === id);

// Deneme ekimin son haftası: tahmini tarih 26 Ekim (pazartesi). Ayarlardan değiştirilebilir.
export const DEFAULT_EXAM_DATE = "2026-10-26";

export function youtubeId(url: string): string | null {
  const m = url.match(/(?:youtu\.be\/|v=|embed\/|shorts\/|live\/)([A-Za-z0-9_-]{11})/);
  return m ? m[1] : null;
}

// "12:34" / "1:02:03" / "754" -> saniye
export function parseTime(s: string): number {
  const p = s.trim().split(":").map((x) => parseInt(x, 10));
  if (p.some((n) => isNaN(n))) return 0;
  return p.reduce((acc, n) => acc * 60 + n, 0);
}

export function fmtTime(sec: number): string {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const two = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${two(m)}:${two(s)}` : `${m}:${two(s)}`;
}

export function daysLeft(examDate: string, now = new Date()): number {
  const d = new Date(examDate + "T09:00:00");
  return Math.max(0, Math.ceil((d.getTime() - now.getTime()) / 86400000));
}

/** Kalan günlere konuları soru ağırlığına göre dağıtır. Bitmiş konular atlanır. */
export function buildPlan(topicIds: string[], days: number): string[][] {
  const n = Math.max(1, days);
  const plan: string[][] = Array.from({ length: n }, () => []);
  const load = new Array(n).fill(0);
  const sorted = topicIds
    .map((id) => findTopic(id)!)
    .filter(Boolean)
    .sort((a, b) => b.q - a.q);
  for (const t of sorted) {
    let i = load.indexOf(Math.min(...load));
    plan[i].push(t.id);
    load[i] += Math.max(2, t.q);
  }
  return plan;
}
