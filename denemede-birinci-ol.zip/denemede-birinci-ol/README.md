# Denemede birinci ol!
1. Bu klasörün içindekileri yeni bir GitHub deposuna yükle (.github klasörü dahil).
2. GitHub'da **Actions** sekmesine gir → "APK Derle" → **Run workflow**.
3. Bitince alttaki **Artifacts** kısmından `Denemede-birinci-ol-APK` dosyasını indir, içindeki `app-debug.apk`'yı telefona kur.
